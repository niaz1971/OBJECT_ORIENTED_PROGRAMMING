#include <iostream>
using namespace std;
//FIND THE AREA OF RECTANGLE of Plot 
//(1) create a class
class Rectangle
{
    // (2)Define Type of Class Private or Public
    public:
    // (3)DECLEARING CLASS DATA MEMBERS
    int height;
    int width;
    // (4) DECLEARING CLASS DATA MEMBERS FUNCTION
    int CalculateAreaRectangle()
    {
        return height * width; // (5) USE FORMULA OF FUNCTION
        }
};
//(6) NOW CREATE OBJECTS
int main()
{
    // (7) GIVE A NAME OF OBJECT WITH NAME OF CLASS
    Rectangle plot;
    // (8) ASSIGN THE VALUES OF DATA MEMBERS WITH OBJECTS
    plot.height = 40;
    plot.width = 30;
    
     cout << "Area of Rectangle Plot =  " << plot.CalculateAreaRectangle() << endl;

    return 0;
}
   