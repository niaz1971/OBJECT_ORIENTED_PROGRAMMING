#include <iostream>
using namespace std;
class Rectangle
{
    private:
        int length;
        int breadth;
    public:
        Rectangle ()
        {
            length = 10;
            breadth = 10;
        }
        Rectangle (int l, int b);
        int Area ();
        int Perimeter ();
        int GetLength ()
        {
            return length;
        }
        void setLength (int l)
        {
            length = l;
        }
        ~Rectangle ();
};
Rectangle::Rectangle (int l, int b)
{
    length = l;
    breadth = b;
}
int Rectangle::Area ()
{
    return length * breadth;
}
int Rectangle::Perimeter ()
{
    return 2 * (length + breadth);
}
Rectangle::~Rectangle ()
{
}
int main ()
{
    Rectangle r (10, 5);
    cout << r.Area ();
    cout << r.Perimeter ();
    r.setLength (20);
    cout << r.GetLength ();
}