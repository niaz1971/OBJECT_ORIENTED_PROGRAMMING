// C++ Program to demonstrate
// the use of Address-of operator (&)
#include <iostream>
using namespace std;
 
int main()
{
    int x = 20;
 
    // Pointer pointing towards x
    int* ptr = &x;
 
    cout << "The address of the variable x is :- " << ptr;
    return 0;
}