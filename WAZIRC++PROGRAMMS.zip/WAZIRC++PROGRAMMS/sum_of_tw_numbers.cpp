#include <iostream>
 
using namespace std;
 
int main() 
{
    int a=3;
    int b = 4;
    int c = (a+b);
    cout << "Sum of Two Numbers = " <<c;
    return 0;
}
