#include<iostream>
using namespace std;
main(){
    int a = 2;
    int b = 3;
    int c = (2*b);
    cout <<"Multiplication of 2 Numbers = "<<c;
    return 0;
}